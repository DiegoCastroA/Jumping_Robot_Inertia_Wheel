%% Par�metros del sistema
g = 9.81; % Gravedad en m/s2
m_b = 0.105;
m_m1 = 0.01;
m_w = 0.072;
Mt = 0.18; % Masa del robot completo
n_g = 298; % Relaci�n entre engranes
bx = 1e-4; % Coeficiente de fricci�n lineal
J_b = 0.129e-3; % Inercia en del cuerpo del robot
J_w = 0.107e-3;  % Inercia de la rueda
J_m1 = 0.57e-6;    % Inercia del motor 1
J_m2 = 0.57e-6;    % Inercia del motor 2
J = 0.424e-3;
D_b = 6.75e-4;  % Coeficiente de fricci�n de la rotaci�n del robot
D_w = 1.4e-3;   % Coeficiente de fricci�n de la rotaci�n de la rueda de inercia
lg = 54.5e-3;
k = (m_b*lg^2*(m_m1+m_w))/Mt;

%% Calculo de matrices del sistema de orientaci�n
... utilizando como gu�a el paper Aerial Attitude Control of Hopping Robots Using Reaction Wheels
M11 = J+k; M12 = J_w + n_g*J_m1; M21 = J_w + n_g*J_m1; M22 = J_w + n_g*n_g*J_m1;
a22 = -D_b*(J_w + n_g*n_g*J_m1); a23 = D_w*(J_w + n_g*J_m1);
a32 = D_b*(J_w + n_g*J_m1); a33 = -D_w*(J+k);
b21 = -(J_w + n_g*J_m1); b31 = J+k;
delta = M11*M22 - M12*M21;
M = [M11 M12; M21 M22];

A = [0 1 0; 0 a22/delta a23/delta; 0 a32/delta a33/delta];
B = [0; b21/delta; b31/delta];
Cr = [1 0 0];
Dr = 0;
AA = [A, zeros(size(Cr')); Cr, zeros(size(Cr,1))];
BB = [B; Dr];
CC = [Cr, zeros(size(Cr,1))];
DD = Dr;

Q = [810 0 0 0; 0 0.7 0 0; 0 0 1 0; 0 0 0 2];
R = 0.1;

% Klqi = lqr(AA, BB, Q, R);
Klqi = -lqi(ss(A, B, Cr, Dr), Q, R);
